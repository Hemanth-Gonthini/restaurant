const fs = require('fs');
const path = require('path');
const https = require('https');

const token = process.argv[2];
const owner = process.argv[3];
const repo = process.argv[4];
const root = path.resolve(process.argv[5] || '.');
if (!token || !owner || !repo) { console.error('Usage: node upload_to_github.js <token> <owner> <repo> [rootDir]'); process.exit(1); }

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const full = path.join(dir, file);
    const stat = fs.statSync(full);
    const rel = path.relative(root, full).replace(/\\/g, '/');
    if (stat && stat.isDirectory()) {
      if (file === '.git' || file === 'node_modules' || file === '.vscode') return;
      results = results.concat(walk(full));
    } else {
      if (rel === 'scripts/upload_to_github.js') return; // skip helper
      if (rel.startsWith('backend/node_modules')) return;
      results.push({ full, rel });
    }
  });
  return results;
}

function putFile(relPath, contentB64) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ message: `add ${relPath}`, content: contentB64 });
    const options = {
      hostname: 'api.github.com', path: `/repos/${owner}/${repo}/contents/${encodeURIComponent(relPath)}`, method: 'PUT',
      headers: { 'User-Agent': 'upload-script', Authorization: `token ${token}`, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    };
    const req = https.request(options, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) return resolve(JSON.parse(data));
        return reject(new Error(`HTTP ${res.statusCode}: ${data}`));
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

(async ()=>{
  try {
    const files = walk(root);
    console.log('Files to upload:', files.length);
    for (const f of files) {
      const buf = fs.readFileSync(f.full);
      const b64 = buf.toString('base64');
      try {
        await putFile(f.rel, b64);
        console.log('Uploaded', f.rel);
      } catch (err) {
        if (err.message && err.message.includes('422')) {
          console.log('Exists, updating', f.rel);
          // get sha
          const getOptions = { hostname: 'api.github.com', path: `/repos/${owner}/${repo}/contents/${encodeURIComponent(f.rel)}`, method: 'GET', headers: { 'User-Agent': 'upload-script', Authorization: `token ${token}` } };
          const sha = await new Promise((resolve, reject)=>{
            const r = https.request(getOptions, res=>{ let d=''; res.on('data',c=>d+=c); res.on('end', ()=>{ if(res.statusCode>=200 && res.statusCode<300){ resolve(JSON.parse(d).sha); } else reject(new Error(d)); }); }); r.on('error', reject); r.end();
          });
          // update
          const body = JSON.stringify({ message: `update ${f.rel}`, content: b64, sha });
          await new Promise((resolve,reject)=>{
            const opts = { hostname: 'api.github.com', path: `/repos/${owner}/${repo}/contents/${encodeURIComponent(f.rel)}`, method: 'PUT', headers: { 'User-Agent': 'upload-script', Authorization: `token ${token}`, 'Content-Type': 'application/json' } };
            const r = https.request(opts, res=>{ let d=''; res.on('data',c=>d+=c); res.on('end', ()=>{ if(res.statusCode>=200 && res.statusCode<300) resolve(JSON.parse(d)); else reject(new Error(d)); }); }); r.on('error', reject); r.write(body); r.end();
          });
          console.log('Updated', f.rel);
        } else {
          console.error('Failed', f.rel, err.message);
        }
      }
    }
    console.log('Upload complete');
  } catch (e) { console.error('ERROR', e.message); process.exit(1); }
})();
